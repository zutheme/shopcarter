<?php
if(!function_exists('subscriber_box')) {
	function subscriber_box(){ 
		echo '<form class="frm">
				<input type="email" name="email" placeholder="E-mail Address" >
				<button type="button" class="btn btn-submit">Subscriber</button>
			</form>';
	 } 
} ?>

  