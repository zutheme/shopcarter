<?php defined( 'ABSPATH' ) or die( 'No script kiddies please!' ); ?>
<?php
/**
 * @wordpress-plugin
 * Plugin Name:       hatazu subscriber
 * Plugin URI:        https://zucommerce.com
 * Description:       subscriber newsletter
 * Version:           0.0.1
 * Author:            hatazu
 * Author URI:         https://zucommerce.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       subsciber
 * Domain Path:       /languages
 * Requires at least: 4.9
 * Tested up to: 5.4
 * WC requires at least: 3.5
 * WC tested up to: 4.1
 */

add_action('admin_menu', 'htz_subscriber_menu_menu');
function htz_subscriber_menu_menu() {
    add_menu_page('menu subscriber Settings', 'option subscriber', 'administrator', 'subscriber-menu-settings', 'subscriber_menu_settings_page', 'dashicons-admin-generic');
}

function subscriber_menu_settings() {
    register_setting( 'subscriber-settings', 'keyapi_mailchimp' );
    register_setting( 'subscriber-settings', 'idlist_mailchimp' );
}

function subscriber_menu_settings_page() {
    include('subscriber-admin.php');
}
add_action( 'admin_init', 'subscriber_menu_settings' );


//add_action('admin_enqueue_scripts', 'admin_load_scripts_subscriber');
function hatazu_subscriber_custom() {
    global $post;
        wp_enqueue_style( 'htz_subscriber_style.css', plugin_dir_url(__FILE__) . 'css/htz_subscriber_style.css',array(), '0.0.4', true);
        wp_enqueue_script( 'htz_subscriber.js', plugin_dir_url(__FILE__) .'js/htz_subscriber.js', array(), '0.0.6.1', false );
       $data = array(
	                'upload_url' => admin_url('async-upload.php'),
	                'ajax_url'   => admin_url('admin-ajax.php'),
	                'nonce'      => wp_create_nonce('media-form')
	            );
	    wp_localize_script( 'htz_subscriber.js', 'htz_config', $data );
}
add_action('wp_enqueue_scripts', 'hatazu_subscriber_custom');
include("include/action.php");  
include("widget.php");
//include_once('MailChimp.php');
include( plugin_dir_path( __FILE__ ) . 'Mailchimp.php');
//add_action('publish_post', 'send_notification');
function send_notification($id, $post_obj){
     
    //Assemble the message
    $msg = 'Hi, a new post has been published. Here is the content:';
    $msg .= $post_obj->post_content;
    // Include Mailchimp API 3.0
     // copy from here: https://github.com/drewm/mailchimp-api/blob/master/src/MailChimp.php

    //use \DrewM\MailChimp\MailChimp;

    /* SET THE VARIABLES HERE BELOW */
    // Configure --------------------------------------
    $api_key = esc_attr(get_option('keyapi_mailchimp'));// see: https://mailchimp.com/help/about-api-keys/
    $list_id = esc_attr(get_option('idlist_mailchimp'));// see: https://mailchimp.com/help/find-your-list-id/
    $subject = "Hello, You've successfully subscribed to our Newsletter!";
    $reply_to = "Your Company Email Address"; 
    $from_name = "Your Company Name";

    $template_id = 99999; // INTEGER
    $template_html = '<p>Ayo whatup? THIS IS THE SAMPLE CONTENT BODY OF MY EMAIL MESSAGE.</p>';
    // STOP Configuring -------------------------------

    // Start create email campaign ->
    $MailChimp = new MailChimp($api_key);

    // Create or Post new Campaign
    $result = $MailChimp->post("campaigns", [
        'type' => 'regular',
        'recipients' => [
            'list_id' => $list_id
        ],
        'settings' => [
            'subject_line' => $subject,
            'reply_to' => $reply_to,
            'from_name' => $from_name
        ]
    ]);

    $response = $MailChimp->getLastResponse();
    $responseObj = json_decode($response['body']);

    $campaign_id = $responseObj->id;

    // Update Template content
    // FYI: Make sure your template is labeled as "Code your own"
    $result = $MailChimp->put('campaigns/' . $campaign_id . '/content', [
        'template' => array(
            'id' => (int)$template_id, 
            'sections' => array(
                'html' => $template_html
            )
        )
    ]);

    // Send Campaign
    $result = $MailChimp->post('campaigns/' . $campaign_id . '/actions/send');  
    //Send the notification
    //wp_mail('recipient@example.com', $post_obj->post_title, $msg);
}
function send_noti(){
     
    //Assemble the message
    $msg = 'Hi, a new post has been published. Here is the content:';
    $msg .= $post_obj->post_content;
    // Include Mailchimp API 3.0
    //include_once('./mailchimp.php'); // copy from here: https://github.com/drewm/mailchimp-api/blob/master/src/MailChimp.php

    //use \DrewM\MailChimp\MailChimp;

    /* SET THE VARIABLES HERE BELOW */
    // Configure --------------------------------------
    $api_key = esc_attr(get_option('keyapi_mailchimp'));// see: https://mailchimp.com/help/about-api-keys/
    $list_id = esc_attr(get_option('idlist_mailchimp'));// see: https://mailchimp.com/help/find-your-list-id/
    $subject = "Hello, You've successfully subscribed to our Newsletter!";
    $reply_to = "Your Company Email Address"; 
    $from_name = "Your Company Name";

    $template_id = 99999; // INTEGER
    $template_html = '<p>Ayo whatup? THIS IS THE SAMPLE CONTENT BODY OF MY EMAIL MESSAGE.</p>';
    // STOP Configuring -------------------------------

    // Start create email campaign ->
    $MailChimp = new \DrewM\MailChimp\MailChimp($api_key);
    //$lists = $MailChimp->get('lists/'.$list_id);
    // Create or Post new Campaign
    $result = $MailChimp->post("campaigns", [
        'type' => 'regular',
        'recipients' => [
            'list_id' => $list_id
        ],
        'settings' => [
            'subject_line' => $subject,
            'reply_to' => $reply_to,
            'from_name' => $from_name
        ]
    ]);

    $response = $MailChimp->getLastResponse();
    $responseObj = json_decode($response['body']);

    $campaign_id = $responseObj->id;

    // Update Template content
    // FYI: Make sure your template is labeled as "Code your own"
    $result = $MailChimp->put('campaigns/' . $campaign_id . '/content', [
        'template' => array(
            'id' => (int)$template_id, 
            'sections' => array(
                'html' => $template_html
            )
        )
    ]);

    // Send Campaign
    $result = $MailChimp->post('campaigns/' . $campaign_id . '/actions/send');  
    //Send the notification
    echo json_encode(array('campaign_id'=>$campaign_id,'responseObj'=>$responseObj));
    wp_die();
}
add_action('wp_ajax_send_noti', 'send_noti');
add_action('wp_ajax_nopriv_send_noti', 'send_noti');
